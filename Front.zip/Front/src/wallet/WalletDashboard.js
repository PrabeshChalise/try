import React, { useEffect, useState } from "react";
import axios from "axios";
import "./WalletDashboard.css"; // Import the CSS file for styling
import image from "./qr.png";
const WalletDashboard = () => {
  const [walletData, setWalletData] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedSymbol, setSelectedSymbol] = useState("BTC");
  const [selectedTab, setSelectedTab] = useState("Receive");
  const [amount, setAmount] = useState("");
  const [usdtValue, setUsdtValue] = useState("");
  const [address, setAddress] = useState("");
  const [showRechargeModal, setShowRechargeModal] = useState(false);
  const [showCryptoModal, setShowCryptoModal] = useState(false); // New state variable
  const [proof, setProof] = useState(null);
  const userId = localStorage.getItem("userId");

  useEffect(() => {
    const fetchWalletData = async () => {
      try {
        const response = await axios.get(
          `http://localhost:3001/api/wallet/${userId}/balances`
        );
        setWalletData(response.data);
        setIsLoading(false);
      } catch (error) {
        console.error("Error fetching wallet data:", error);
        setIsLoading(false);
      }
    };

    fetchWalletData();
  }, [userId]);

  useEffect(() => {
    if (
      walletData &&
      walletData.prices &&
      amount &&
      walletData.prices[selectedSymbol]?.usd
    ) {
      setUsdtValue((amount * walletData.prices[selectedSymbol].usd).toFixed(2));
    } else {
      setUsdtValue("");
    }
  }, [amount, selectedSymbol, walletData]);

  const handleTabClick = (tab) => {
    setSelectedTab(tab);
  };

  const handleCryptoClick = (symbol) => {
    setSelectedSymbol(symbol);
    setSelectedTab("Receive"); // Default to the "Receive" tab
    setShowCryptoModal(true); // Show the crypto modal
  };

  const handlePaste = async () => {
    const text = await navigator.clipboard.readText();
    setAddress(text);
  };

  const handleMax = () => {
    const maxAmount = walletData?.balances[selectedSymbol] || 0;
    setAmount(maxAmount);
  };

  const handleSendSubmit = async (e) => {
    e.preventDefault();

    try {
      await axios.post("http://localhost:3001/api/send", {
        userId,
        symbol: selectedSymbol,
        amount: parseFloat(amount),
        address,
      });
      alert("Send request submitted successfully");
      setAmount("");
      setAddress("");
    } catch (error) {
      console.error("Error submitting send request:", error);
      alert("Failed to submit send request");
    }
  };

  const handleConvertSubmit = async (e) => {
    e.preventDefault();

    try {
      await axios.post("http://localhost:3001/api/withdraw", {
        userId,
        symbol: selectedSymbol,
        amount: parseFloat(amount),
      });
      alert("Conversion request submitted successfully");
      setAmount("");
      setUsdtValue("");
    } catch (error) {
      console.error("Error submitting conversion request:", error);
      alert("Failed to submit conversion request");
    }
  };

  const handleRechargeSubmit = async (e) => {
    e.preventDefault();

    const formData = new FormData();
    formData.append("amount", amount);
    formData.append("proof", proof);
    formData.append("userId", userId);

    try {
      await axios.post("http://localhost:3001/api/deposit", formData);
      alert("Deposit request submitted successfully");
      setAmount("");
      setProof(null);
      setShowRechargeModal(false);
    } catch (error) {
      console.error("Error submitting deposit request:", error);
      alert("Failed to submit deposit request");
    }
  };

  if (isLoading) {
    return <div>Loading...</div>;
  }

  if (!walletData) {
    return <div>Error fetching wallet data.</div>;
  }

  const { balances, prices } = walletData || { balances: {}, prices: {} };

  const totalBalance = Object.keys(balances).reduce(
    (acc, symbol) => acc + balances[symbol] * (prices[symbol]?.usd || 0),
    0
  );

  return (
    <div className="container">
      <header>
        <div className="icons">
          <h1>Crypto</h1>
          <img
            src="/mnt/data/image.png"
            className="icon-notification"
            alt="Notification Bell"
          />
          <button className="menu-button">&#9776;</button>
        </div>
      </header>

      <div className="main-content">
        <div className="banner">
          <h2>Encryption tools for everyone</h2>
          <p>Intelligently trade cryptocurrencies on the world's</p>
        </div>
        <div className="market-tabs">
          <button className="active">Digital Currency</button>
          <button>Foreign Exchange</button>
          <button>Precious Metals</button>
        </div>
        <div className="market-list">
          {Object.keys(balances)
            .filter((symbol) => symbol !== "USD")
            .map((symbol) => (
              <div
                key={symbol}
                className="market-item"
                onClick={() => handleCryptoClick(symbol)}
              >
                <div className="market-info">
                  <h3>{symbol.toUpperCase()} Coin</h3>
                  <p>USDT</p>
                </div>
                <div className="market-stats">
                  <p>
                    US${" "}
                    {prices[symbol]?.usd
                      ? prices[symbol].usd.toFixed(2)
                      : "0.00"}
                  </p>
                </div>
              </div>
            ))}
        </div>
      </div>

      {showCryptoModal && (
        <div className="modal" id="crypto-modal">
          <div className="modal-content">
            <span className="close" onClick={() => setShowCryptoModal(false)}>
              &times;
            </span>
            <div className="wallet">
              <div className="wallet-header">
                <h1>{selectedSymbol.toUpperCase()} Wallet</h1>
              </div>
              <div className="wallet-balance">
                <p>
                  US${" "}
                  {(
                    (balances[selectedSymbol] || 0) *
                    (prices[selectedSymbol]?.usd || 0)
                  ).toFixed(4)}
                </p>
                <p>
                  Available: {balances[selectedSymbol] || 0}{" "}
                  {selectedSymbol.toUpperCase()}
                </p>
                <p>Frozen: 0.0000000 {selectedSymbol.toUpperCase()}</p>
              </div>
              <div className="wallet-tabs">
                <button
                  data-tab="Receive"
                  className={selectedTab === "Receive" ? "active" : ""}
                  onClick={() => handleTabClick("Receive")}
                >
                  Receive
                </button>
                <button
                  data-tab="Send"
                  className={selectedTab === "Send" ? "active" : ""}
                  onClick={() => handleTabClick("Send")}
                >
                  Send
                </button>
                <button
                  data-tab="Convert"
                  className={selectedTab === "Convert" ? "active" : ""}
                  onClick={() => handleTabClick("Convert")}
                >
                  Convert
                </button>
              </div>
              {selectedTab === "Receive" && (
                <div id="Receive" className="tab-content active">
                  <p>Deposit funds</p>
                  <div className="wallet-buttons">
                    <span
                      className="recharge-link"
                      onClick={() => setShowRechargeModal(true)}
                    >
                      Recharge
                    </span>
                  </div>
                  <div className="wallet-qr">
                    <div
                      style={{
                        display: "flex",
                        justifyContent: "center",
                        alignItems: "center",
                        textAlign: "center",
                      }}
                    >
                      {" "}
                      <img src={image} alt="QR Code" />
                    </div>

                    <p id="btc-address">
                      bc1qm7m3aw57lla4nt9l880rhj0yhs5gfnzw7ft43s
                    </p>
                    <p
                      className="copy-address"
                      onClick={() =>
                        navigator.clipboard.writeText("3ghadsb893p2lsand")
                      }
                    >
                      Copy address
                    </p>
                  </div>
                </div>
              )}
              {selectedTab === "Send" && (
                <div id="Send" className="tab-content active">
                  <p>Send Cryptocurrency</p>
                  <form onSubmit={handleSendSubmit}>
                    <div className="form-group">
                      <label>Amount:</label>
                      <input
                        type="number"
                        value={amount}
                        onChange={(e) => setAmount(e.target.value)}
                        required
                      />
                      <button type="button" onClick={handleMax}>
                        Max
                      </button>
                    </div>
                    <div className="form-group">
                      <label>Wallet Address:</label>
                      <input
                        type="text"
                        value={address}
                        onChange={(e) => setAddress(e.target.value)}
                        required
                      />
                      <button type="button" onClick={handlePaste}>
                        Paste
                      </button>
                    </div>
                    <button type="submit" className="send-button">
                      Submit
                    </button>
                  </form>
                </div>
              )}
              {selectedTab === "Convert" && (
                <div id="Convert" className="tab-content active">
                  <p>Convert {selectedSymbol.toUpperCase()} to USDT</p>
                  <form onSubmit={handleConvertSubmit}>
                    <div className="wallet-buttons">
                      <span className="currency-tag">From</span>
                      <span className="currency">
                        {selectedSymbol.toUpperCase()}
                      </span>
                      <input
                        type="number"
                        value={amount}
                        onChange={(e) => setAmount(e.target.value)}
                        placeholder="0"
                        className="input-field small-input"
                        required
                      />
                      <span className="max-button" onClick={handleMax}>
                        Max
                      </span>
                    </div>
                    <div className="wallet-buttons">
                      <span className="currency-tag">To</span>
                      <span className="currency">USDT</span>
                      <input
                        type="text"
                        value={usdtValue}
                        placeholder="0"
                        className="input-field small-input"
                        readOnly
                      />
                    </div>
                    <button type="submit" className="convert-button">
                      Proceed to pin
                    </button>
                  </form>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {showRechargeModal && (
        <div className="modal" id="recharge-modal">
          <div className="modal-content">
            <span className="close" onClick={() => setShowRechargeModal(false)}>
              &times;
            </span>
            <h2>Submit Recharge Order</h2>
            <form onSubmit={handleRechargeSubmit}>
              <div className="form-group">
                <label>Currency</label>
                <input
                  type="text"
                  value={selectedSymbol.toUpperCase()}
                  readOnly
                />
              </div>
              <div className="form-group">
                <label>Network</label>
                <input
                  type="text"
                  value={selectedSymbol.toUpperCase()}
                  readOnly
                />
              </div>
              <div className="form-group">
                <label>Address</label>
                <input type="text" value="3ghadsb893p2lsand" readOnly />
              </div>
              <div className="form-group">
                <label>Amount</label>
                <input
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="Please enter the amount"
                  required
                />
              </div>
              <div className="form-group">
                <label>Upload Screenshot</label>
                <div
                  className="upload-screenshot"
                  onClick={() => document.getElementById("file-upload").click()}
                >
                  <span className="upload-icon">&#128247;</span>
                  <p id="upload-text">
                    Please upload a screenshot of your successful transfer
                  </p>
                  <img
                    id="uploaded-image"
                    style={{
                      display: "none",
                      maxWidth: "100%",
                      height: "auto",
                    }}
                    alt="uploaded"
                  />
                </div>
                <input
                  type="file"
                  id="file-upload"
                  style={{ display: "none" }}
                  accept="image/*"
                  onChange={(e) => {
                    const file = e.target.files[0];
                    const reader = new FileReader();
                    reader.onload = (event) => {
                      document.getElementById("uploaded-image").src =
                        event.target.result;
                      document.getElementById("uploaded-image").style.display =
                        "block";
                      document.getElementById("upload-text").style.display =
                        "none";
                    };
                    reader.readAsDataURL(file);
                    setProof(file);
                  }}
                />
              </div>
              <button type="submit" className="submit-button">
                Submit
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default WalletDashboard;
