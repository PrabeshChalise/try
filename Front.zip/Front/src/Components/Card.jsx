import axios from "axios";
import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import "../wallet/WalletDashboard.css"; // Import the CSS file for styling

export default function Card() {
  const url =
    "https://api.coingecko.com/api/v3/coins/markets?vs_currency=inr&order=market_cap_desc&per_page=100&page=1&sparkline=true";
  const [info, setinfo] = useState([]);
  const [showCryptoModal, setShowCryptoModal] = useState(false);
  const [selectedCrypto, setSelectedCrypto] = useState(null);
  const [isMenuOpen, setIsMenuOpen] = useState(false); // State to manage menu visibility
  const navigate = useNavigate();

  useEffect(() => {
    axios.get(url).then((response) => {
      setinfo(response.data);
    });
  }, []);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  if (info.length === 0) {
    return <div>Loading...</div>;
  } else {
    return (
      <div className="container">
        <header>
          <div className="icons">
            <h1>Crypto</h1>
            <img
              src="/mnt/data/image.png"
              className="icon-notification"
              alt="Notification Bell"
            />
            <button className="menu-button" onClick={toggleMenu}>
              &#9776;
            </button>
          </div>
        </header>

        <div className="main-content">
          <div className="banner">
            <h2>Encryption tools for everyone</h2>
            <p>Intelligently trade cryptocurrencies on the world's</p>
          </div>
          <div className="market-tabs">
            <button className="active">Digital Currency</button>
          </div>
          <div className="market-list">
            {info.map((value, key) => {
              if (key < 20) {
                return (
                  <div
                    key={key}
                    className="market-item"
                    onClick={() => navigate("/predict", { state: { value } })}
                  >
                    <div className="market-info">
                      <h3>{value.name}</h3>
                      <p>{value.symbol.toUpperCase()}</p>
                    </div>
                    <div className="market-stats">
                      <p>₹{value.current_price}</p>
                      <p
                        className={
                          value.price_change_percentage_24h < 0
                            ? "negative"
                            : "positive"
                        }
                      >
                        {value.price_change_percentage_24h.toFixed(2)}%
                      </p>
                    </div>
                  </div>
                );
              }
            })}
          </div>
        </div>

        <div className={`nav-menu ${isMenuOpen ? "open" : ""}`}>
          <div className="nav-content">
            <button className="close-button" onClick={toggleMenu}>
              &times;
            </button>
            <ul>
              <li>
                <Link to="/">Home</Link>
              </li>
              <li>
                <button onClick={() => navigate("/dashboard")}>
                  Dashboard
                </button>
              </li>
              <li>
                <button onClick={() => navigate("/trade")}>Trade</button>
              </li>
              <li>
                <button onClick={() => navigate("/result")}>Result</button>
              </li>
              <li>
                <button
                  onClick={() => {
                    localStorage.removeItem("authToken");
                    navigate("/");
                  }}
                >
                  Logout
                </button>
              </li>
            </ul>
          </div>
        </div>

        {showCryptoModal && selectedCrypto && (
          <div className="modal" id="crypto-modal">
            <div className="modal-content">
              <span className="close" onClick={() => setShowCryptoModal(false)}>
                &times;
              </span>
              <div className="wallet">
                <div className="wallet-header">
                  <h1>{selectedCrypto.name} Wallet</h1>
                </div>
                <div className="wallet-balance">
                  <p>₹{selectedCrypto.current_price}</p>
                  <p>
                    Available: {selectedCrypto.circulating_supply}{" "}
                    {selectedCrypto.symbol.toUpperCase()}
                  </p>
                  <p>High 24h: ₹{selectedCrypto.high_24h}</p>
                  <p>Low 24h: ₹{selectedCrypto.low_24h}</p>
                </div>
                <div className="wallet-qr">
                  <div
                    style={{
                      display: "flex",
                      justifyContent: "center",
                      alignItems: "center",
                      textAlign: "center",
                    }}
                  >
                    <img
                      src={`https://api.qrserver.com/v1/create-qr-code/?data=${selectedCrypto.symbol}Address&size=150x150`}
                      alt="QR Code"
                    />
                  </div>
                  <p id="btc-address">3ghadsb893p2lsand</p>
                  <p
                    className="copy-address"
                    onClick={() =>
                      navigator.clipboard.writeText("3ghadsb893p2lsand")
                    }
                  >
                    Copy address
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }
}
